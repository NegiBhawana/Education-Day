const testimonials = [
  {
    name: 'Sheldon Cooper',
    image: './image/Testimonials/users/user-4.jpg',
    heading: 'Guitarzilla is the best!',
    text: 'Kids can learn in a calm and friendly atmosphere in individual classes not only that the teacher are so fiendly with the kids my daughter is throughly Enjoying with you.',
    address: 'San Francisco, USA',
  },
  {
    name: 'Lilly peter',
    image: './image/Testimonials/users/user-2.jpg',
    heading: 'So much improvement in short time period',
    text: 'I wanted to play guitar faster and have been able to start playing my first song in just 2 weeks, love the one-on-one individual classes! I highly recommend it.',
    address: '78 Overton Circle, UK',
  },
  {
    name: 'Amy Farrah Fowler',
    image: './image/Testimonials/users/user-3.jpg',
    heading: 'Experienced Teachers and a great team ',
    text: 'Good experience with the team! Teacher is engaging with the learner quite in detail and my girl enjoys learning from the teacher! There are regular updates on what’s going on from the team! Good job',
    address: '71 Norton Street, Australia',
  },
  {
    name: 'Harry potter',
    image: './image/Testimonials/users/user-1.jpg',
    heading: 'I love their teaching style',
    text: 'I look forward to my LIVE class with Guitarzilla, I’ve improved so much in such a short time.',
    address: 'Thamel Kathmandu, Nepal',
  },
  {
    name: 'Rajesh kootrappali',
    image: './image/Testimonials/users/user-5.jpg',
    heading: 'Thank You so much I won',
    text: 'Thanks to the Guitarzilla LIVE Western vocal classes, I won my singing competition! Thank you to my teacher and Guitarzilla!.',
    address: 'Subhash Rd, Vile Parle, Mumbai',
  },
];

export default testimonials;
